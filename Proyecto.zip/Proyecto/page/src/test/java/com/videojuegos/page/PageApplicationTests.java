package com.videojuegos.page;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PageApplicationTests {

	@Test
	void contextLoads() {
	}

}
