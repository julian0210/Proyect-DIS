package com.videojuegos.page.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class GamesController {
    
    @RequestMapping("/")
    public String principal(){
        return "Principal_page";
    }

    @RequestMapping("/Create")
    public String Users(){
        return "Crear_User";
    }

    @RequestMapping("/Login")
    public String Login(){  
    return "Login_Proyect";
    }
    
}
