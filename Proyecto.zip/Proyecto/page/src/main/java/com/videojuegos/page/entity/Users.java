package com.videojuegos.page.entity;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Users")
public class Users {
    
    @Id
    @GeneratedValue
    private Long Id;

    @Column(name = "name", nullable = false)
    private String Name;

    @Column(name = "Contraseña")
    private Long Contraseña;
    
    @Column(name = "Correo")
    private String Correo;
    
    @ManyToMany(fetch = FetchType.LAZY, cascade = CascadeType.PERSIST)
    @JoinTable(name = "Games_Users", joinColumns={
        @JoinColumn(name = "User_Id", referencedColumnName = "id", nullable = false, updatable = false)
    }, inverseJoinColumns = {
        @JoinColumn(name = "Games_id", referencedColumnName = "id",nullable = false,updatable = false)
    })
    private Set<Games> game = new HashSet<>();

    public Users(String name, Long contraseña, String correo) {
        Name = name;
        Contraseña = contraseña;
        Correo = correo;
    }

    public Users() {
    }

    public Long getId() {
        return Id;
    }

    public void setId(Long id) {
        Id = id;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public Long getContraseña() {
        return Contraseña;
    }

    public void setContraseña(Long contraseña) {
        Contraseña = contraseña;
    }

    public String getCorreo() {
        return Correo;
    }

    public void setCorreo(String correo) {
        Correo = correo;
    }

    public Set<Games> getGame() {
        return game;
    }

    public void setGame(Set<Games> game) {
        this.game = game;
    }

    @Override
    public String toString() {
        return "Users [Name=" + Name + ", Contraseña=" + Contraseña + ", Correo=" + Correo + "]";
    }
    
    
    
}
