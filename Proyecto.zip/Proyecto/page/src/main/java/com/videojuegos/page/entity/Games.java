package com.videojuegos.page.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Games")
public class Games {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    
    private String nameGame;

    @Column(name = "Company")
    private String Company;

    @Column(name = "Plataformas")
    private String Platafomas;


    public Games(){
    }

    public Games(String nameGame, String Company, String Plataformas){
       this.nameGame = nameGame;    
       this.Company = Company;
       this.Platafomas = Plataformas;
    }

    public Long getId(){
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNameGame() {
        return nameGame;
    }

    public void setNameGame(String nameGame) {
        this.nameGame = nameGame;
    }

    public String getCompany() {
        return Company;
    }

    public void setCompany(String company) {
        Company = company;
    }

    public String getPlatafomas() {
        return Platafomas;
    }

    public void setPlatafomas(String platafomas) {
        Platafomas = platafomas;
    }

    @Override
    public String toString() {
        return "Games [nameGame=" + nameGame + ", Company=" + Company + ", Platafomas=" + Platafomas + "]";
    }
    
}
